-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2023 at 10:42 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `contactusdb`
--
CREATE DATABASE IF NOT EXISTS `contactusdb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `contactusdb`;

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactus`
--

CREATE TABLE `tblcontactus` (
  `idcontactus` int(10) NOT NULL,
  `fname` varchar(32) NOT NULL,
  `email` varchar(64) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `message` longtext NOT NULL,
  `insertdatetime` longtext NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblcontactus`
--

INSERT INTO `tblcontactus` (`idcontactus`, `fname`, `email`, `mobile`, `message`, `insertdatetime`) VALUES
(1, 'Akash Tangadkar', 'akashtangadkar96@gmail.com', '9370902520', 'hiii', '2023-03-25 07:02:35'),
(2, 'Akash Tangadkar', 'akashtangadkar96@gmail.com', '9370902520', 'hi', '2023-03-26 12:54:50'),
(3, 'Ram', 'ram@gmail.com', '9975249349', 'hi this is very nice website', '2023-03-30 09:07:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  ADD PRIMARY KEY (`idcontactus`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  MODIFY `idcontactus` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
