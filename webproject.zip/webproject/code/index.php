<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The top 10 Expensive Cars</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script>


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        img,li,input,textarea{
            transition:transform 2s;
        }

    </style>

    <script>
        $(document).ready(function () {
            $("input").focus(function () {
                $(this).css("background-color", "yellow");
            });
            $("input").blur(function () {
                $(this).css("background-color", "lightgray");
            });
            $("input").change(function () {
                $("#p3").html("input changed value is : " + $(this).val());
            });
            $("form").submit(function () {
                alert("Submitted");
            });

            $("li,img,input,textarea").mouseenter(function () {
                $(this).css("transform", "scale(1.1)");
                $(this).css("background-color", "green");
                $(this).css("color", "red");
            });

            $("img,input,textarea").mouseleave(function () {
                $(this).css("transform", "scale(1)");
                $(this).css("background-color", "white");
                $(this).css("color", "black");
            });
            $("li").mouseleave(function () {
                $(this).css("transform", "scale(1)");
                $(this).css("background-color", "");
                $(this).css("color", "black");
            });
            $("input[type-submit]").mouseenter(function () {
                $(this).css("transform", "scale(1.1)");
            });
            $("input[type-submit]").mouseleave(function () {
                $(this).css("transform", "scale(1)");
            });
            $('h1').mouseenter(function(){
                $(this).css("backgroundcolor","yellow");
                $(this).css("color", "blue");
            });
            $('h1').mouseleave(function(){
                $(this).css("backgroundcolor","White");
                $(this).css("color", "black");
            });


            $('h3').mouseenter(function(){
                $(this).css("transform","scale(1.1)");
                $(this).css("backgroundcolor","aqua");
                $(this).css("color", "red");
            });
            $('h3').mouseleave(function(){
                $(this).css("transform","scale(1)");
                $(this).css("backgroundcolor","White");
                $(this).css("color", "black");
            });
            $('h2').mouseenter(function(){
                $(this).css("backgroundcolor","yellow");
                $(this).css("color", "red");
            });
            $('h2').mouseleave(function(){
                $(this).css("backgroundcolor","White");
                $(this).css("color", "black");
            });





        });


    </script>
</head>

<body class="bg-">
    
    <?php
       include_once("home.php");
    ?>   

    
    
</body>
</html>