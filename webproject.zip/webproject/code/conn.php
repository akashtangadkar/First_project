<?php
date_default_timezone_set("Asia/kolkata");
$servername="localhost";
$username="root";
$password="";

//create connection
$conn=mysqli_connect($servername,$username,$password);

if(!$conn) {
    die("Conection failed".mysql_connect_error());

}
mysqli_select_db($conn,'contactusdb');
?>



