<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The top 10 Expensive Cars</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://www.cars24.com/blog/wp-content/themes/cars24/css/main.css?ver=2.21">
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">

    <script type="text/javascript" src="https://cdn.taboola.com/scripts/eid.es5.js" charset="UTF-8" async="async"></script>
    <script type="text/javascript" src="https://cdn.taboola.com/scripts/cds-pips.js" charset="UTF-8" async="async"></script>
    <script type="text/javascript" async="" src="https://www.google-analytics.com/plugins/ua/linkid.js"></script>
    <script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script>
    <script id="c24-chatbot-widget" type="text/javascript" src="https://chatbot.cars24.com/chatbot.js?v=6"></script>
    <script async="" src="https://cdn.branch.io/branch-latest.min.js"></script>
    <script type="text/javascript" defer="" async="" src="https://cars24-com.dcmn.com/t190.js"></script>
    <script type="text/javascript" async="" src="https://www.googletagmanager.com/gtag/js?id=G-7NRSDZCSZW&amp;l=dataLayer&amp;cx=c"></script>
    <script async="" src="//cdn.taboola.com/libtrc/unip/1466718/tfa.js" id="tb_tfa_script"></script>
    <script type="text/javascript" async="" src="//tgtag.io/tg.js?pid=tg-g-004174-001"></script>
    <script src="https://c.amazon-adsystem.com/aat/amzn.js" id="amzn-pixel" async=""></script>
    <script src="https://s.yimg.com/wi/ytc.js" async=""></script>
    <script async="" src="//widgets.getsitecontrol.com/125452/script.js"></script>
    <script async="" src="https://a.quora.com/qevents.js"></script>
    <script src="https://connect.facebook.net/signals/config/1594462310820300?v=2.9.100&amp;r=stable" async=""></script>
    <script async="" src="https://connect.facebook.net/en_US /fbevents.js"></script>
    <script async="" src="https://tracking.cars24.com/static/DhPixel.js"></script>
    <script src="//bat.bing.com/bat.js" async=""></script>
    <script gtm="GTM-P3C9RJ" type="text/javascript" async="" src="https://www.google-analytics.com/gtm/optimize.js?id=GTM-NFJTXNR"></script>
    <script type="text/javascript" async="" src="https://www.gstatic.com/recaptcha/releases/vpEprwpCoBMgy-fvZET0Mz6L/recaptcha__en.js" crossorigin="anonymous" integrity="sha384-jffSm4FBmQyLvL1V8BXFUBdZCFkPLi8N+X9NGYs2YKU4uUiYzy53t/3mlwj1fdwI"></script>
    <script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-P3C9RJ"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous" type="text/javascript"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous" type="text/javascript"></script>

    <!--google-site-verification-->
    <meta name="google-site-verification" content="03rwPmqXHzwoiXgtCFSsJ1j95JQl3YainCchSn82DA0">
    <!--google-site-verification-->

    <!-- Google Tag Manager -->
    <script type="text/javascript">
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-P3C9RJ');
    </script>
    <!-- End Google Tag Manager -->

    <!-- Google Tag Manager (noscript) -->
    <noscript>
        <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P3C9RJ" height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript>

    <!-- End Google Tag Manager (noscript) -->




    <script type="text/javascript">
        (function(html) {
            html.className = html.className.replace(/\bno-js\b/, 'js')
        })(document.documentElement);
    </script>
    <title>10 Most Expensive Cars in the World in 2022</title>
    <script type="text/javascript">
        function heateorSssLoadEvent(e) {
            var t = window.onload;
            if (typeof window.onload != "function") {
                window.onload = e
            } else {
                window.onload = function() {
                    t();
                    e()
                }
            }
        };
        var heateorSssSharingAjaxUrl = 'https://www.cars24.com/blog/wp-admin/admin-ajax.php',
            heateorSssCloseIconPath = 'https://www.cars24.com/blog/wp-content/plugins/sassy-social-share/public/../images/close.png',
            heateorSssPluginIconPath = 'https://www.cars24.com/blog/wp-content/plugins/sassy-social-share/public/../images/logo.png',
            heateorSssHorizontalSharingCountEnable = 0,
            heateorSssVerticalSharingCountEnable = 0,
            heateorSssSharingOffset = -10;
        var heateorSssMobileStickySharingEnabled = 1;
        var heateorSssCopyLinkMessage = "Link copied.";
        var heateorSssUrlCountFetched = [],
            heateorSssSharesText = 'Shares',
            heateorSssShareText = 'Share';

        function heateorSssPopup(e) {
            window.open(e, "popUpWindow", "height=400,width=600,left=400,top=100,resizable,scrollbars,toolbar=0,personalbar=0,menubar=no,location=no,directories=no,status")
        };
        var heateorSssWhatsappShareAPI = "web";
    </script>
    <style type="text/css">
        .heateor_sss_horizontal_sharing .heateorSssSharing,
        .heateor_sss_standard_follow_icons_container .heateorSssSharing {
            background-color: #000000;
            color: #fff;
            border-width: 0px;
            border-style: solid;
            border-color: transparent;
        }

        .heateor_sss_horizontal_sharing .heateorSssTCBackground {
            color: #666;
        }

        .heateor_sss_horizontal_sharing .heateorSssSharing:hover,
        .heateor_sss_standard_follow_icons_container .heateorSssSharing:hover {
            border-color: transparent;
        }

        .heateor_sss_vertical_sharing .heateorSssSharing,
        .heateor_sss_floating_follow_icons_container .heateorSssSharing {
            background-color: #000;
            color: #fff;
            border-width: 0px;
            border-style: solid;
            border-color: transparent;
        }

        .heateor_sss_vertical_sharing .heateorSssTCBackground {
            color: #666;
        }

        .heateor_sss_vertical_sharing .heateorSssSharing:hover,
        .heateor_sss_floating_follow_icons_container .heateorSssSharing:hover {
            border-color: transparent;
        }

        @media screen and (max-width:783px) {
            .heateor_sss_vertical_sharing {
                display: none !important
            }
        }

        div.heateor_sss_mobile_footer {
            display: none;
        }

        @media screen and (max-width:783px) {
            i.heateorSssTCBackground {
                background-color: white !important
            }

            div.heateor_sss_bottom_sharing {
                width: 100% !important;
                left: 0 !important;
            }

            div.heateor_sss_bottom_sharing li {
                width: 33.333333333333% !important;
            }

            div.heateor_sss_bottom_sharing .heateorSssSharing {
                width: 100% !important;
            }

            div.heateor_sss_bottom_sharing div.heateorSssTotalShareCount {
                font-size: 1em !important;
                line-height: 24.5px !important
            }

            div.heateor_sss_bottom_sharing div.heateorSssTotalShareText {
                font-size: .7em !important;
                line-height: 0px !important
            }

            div.heateor_sss_mobile_footer {
                display: block;
                height: 35px;
            }

            .heateor_sss_bottom_sharing {
                padding: 0 !important;
                display: block !important;
                width: auto !important;
                bottom: -2px !important;
                top: auto !important;
            }

            .heateor_sss_bottom_sharing .heateor_sss_square_count {
                line-height: inherit;
            }

            .heateor_sss_bottom_sharing .heateorSssSharingArrow {
                display: none;
            }

            .heateor_sss_bottom_sharing .heateorSssTCBackground {
                margin-right: 1.1em !important
            }
        }
    </style>
    <!-- This site is optimized with the Yoast SEO plugin v11.5 - https://yoast.com/wordpress/plugins/seo/ -->
    <meta name="description" content="The ten most expensive cars in the world in 2022 include the Rolls Royce Boat Tail ($28 million), Buggati La Voiture Noire ($18.7 million),Buggati Centodieci ($9 million) and more.">
    <link rel="canonical" href="https://www.cars24.com/blog/10-most-expensive-cars-in-the-world/">
    <meta property="og:locale" content="en_US">
    <meta property="og:type" content="article">
    <meta property="og:title" content="10 Most Expensive Cars in the World in 2022">
    <meta property="og:description" content="The ten most expensive cars in the world in 2022 include the Rolls Royce Boat Tail ($28 million), Buggati La Voiture Noire ($18.7 million),Buggati Centodieci ($9 million) and more.">
    <meta property="og:url" content="https://www.cars24.com/blog/10-most-expensive-cars-in-the-world/">
    <meta property="og:site_name" content="All About Buying &amp; Selling of Used Cars, New Car Launches">
    <meta property="article:tag" content="News">
    <meta property="article:section" content="Latest News">
    <meta property="article:published_time" content="2022-02-10T06:53:02+05:30">
    <meta property="article:modified_time" content="2022-02-10T11:13:39+05:30">
    <meta property="og:updated_time" content="2022-02-10T11:13:39+05:30">
    <meta property="og:image" content="https://www.cars24.com/blog/wp-content/uploads/2022/02/Buggati-Centodieci.jpg">
    <meta property="og:image:secure_url" content="https://www.cars24.com/blog/wp-content/uploads/2022/02/Buggati-Centodieci.jpg">
    <meta property="og:image:width" content="1000">
    <meta property="og:image:height" content="666">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:description" content="The ten most expensive cars in the world in 2022 include the Rolls Royce Boat Tail ($28 million), Buggati La Voiture Noire ($18.7 million),Buggati Centodieci ($9 million) and more.">
    <meta name="twitter:title" content="10 Most Expensive Cars in the World in 2022">
    <meta name="twitter:image" content="https://www.cars24.com/blog/wp-content/uploads/2022/02/Buggati-Centodieci.jpg">
    <script type="application/ld+json" class="yoast-schema-graph yoast-schema-graph--main">
        {
            "@context": "https://schema.org",
            "@graph": [{
                "@type": "Organization",
                "@id": "https://www.cars24.com/blog/#organization",
                "name": "Cars24",
                "url": "https://www.cars24.com/blog/",
                "sameAs": [],
                "logo": {
                    "@type": "ImageObject",
                    "@id": "https://www.cars24.com/blog/#logo",
                    "url": "https://www.cars24.com/blog/wp-content/uploads/2019/08/cars24-logo.png",
                    "width": 200,
                    "height": 96,
                    "caption": "Cars24"
                },
                "image": {
                    "@id": "https://www.cars24.com/blog/#logo"
                }
            }, {
                "@type": "WebSite",
                "@id": "https://www.cars24.com/blog/#website",
                "url": "https://www.cars24.com/blog/",
                "name": "All About Buying &amp; Selling of Used Cars, New Car Launches",
                "publisher": {
                    "@id": "https://www.cars24.com/blog/#organization"
                },
                "potentialAction": {
                    "@type": "SearchAction",
                    "target": "https://www.cars24.com/blog/?s={search_term_string}",
                    "query-input": "required name=search_term_string"
                }
            }, {
                "@type": "ImageObject",
                "@id": "https://www.cars24.com/blog/10-most-expensive-cars-in-the-world/#primaryimage",
                "url": "https://www.cars24.com/blog/wp-content/uploads/2022/02/Buggati-Centodieci.jpg",
                "width": 1000,
                "height": 666
            }, {
                "@type": "WebPage",
                "@id": "https://www.cars24.com/blog/10-most-expensive-cars-in-the-world/#webpage",
                "url": "https://www.cars24.com/blog/10-most-expensive-cars-in-the-world/",
                "inLanguage": "en-US",
                "name": "10 Most Expensive Cars in the World in 2022",
                "isPartOf": {
                    "@id": "https://www.cars24.com/blog/#website"
                },
                "primaryImageOfPage": {
                    "@id": "https://www.cars24.com/blog/10-most-expensive-cars-in-the-world/#primaryimage"
                },
                "datePublished": "2022-02-10T06:53:02+05:30",
                "dateModified": "2022-02-10T11:13:39+05:30",
                "description": "The ten most expensive cars in the world in 2022 include the Rolls Royce Boat Tail ($28 million), Buggati La Voiture Noire ($18.7 million),Buggati Centodieci ($9 million) and more."
            }, {
                "@type": "Article",
                "@id": "https://www.cars24.com/blog/10-most-expensive-cars-in-the-world/#article",
                "isPartOf": {
                    "@id": "https://www.cars24.com/blog/10-most-expensive-cars-in-the-world/#webpage"
                },
                "author": {
                    "@id": "https://www.cars24.com/blog/author/divyanshi-bhardwaj/#author"
                },
                "headline": "10 Most Expensive Cars in the World in 2022",
                "datePublished": "2022-02-10T06:53:02+05:30",
                "dateModified": "2022-02-10T11:13:39+05:30",
                "commentCount": 0,
                "mainEntityOfPage": {
                    "@id": "https://www.cars24.com/blog/10-most-expensive-cars-in-the-world/#webpage"
                },
                "publisher": {
                    "@id": "https://www.cars24.com/blog/#organization"
                },
                "image": {
                    "@id": "https://www.cars24.com/blog/10-most-expensive-cars-in-the-world/#primaryimage"
                },
                "keywords": "News",
                "articleSection": "Latest News,Others"
            }, {
                "@type": ["Person"],
                "@id": "https://www.cars24.com/blog/author/divyanshi-bhardwaj/#author",
                "name": "Divyanshi Bhardwaj",
                "image": {
                    "@type": "ImageObject",
                    "@id": "https://www.cars24.com/blog/#authorlogo",
                    "url": "https://secure.gravatar.com/avatar/cb4ec63fe1e441976b1f0a9295664b64?s=96&d=mm&r=g",
                    "caption": "Divyanshi Bhardwaj"
                },
                "sameAs": []
            }]
        }
    </script>
    <!-- / Yoast SEO plugin. -->

    <link rel="dns-prefetch" href="//fonts.googleapis.com">
    <link rel="dns-prefetch" href="//s.w.org">
    <link href="https://fonts.gstatic.com" crossorigin="" rel="preconnect">
    <link rel="alternate" type="application/rss+xml" title="All About Buying &amp; Selling of Used Cars, New Car Launches » Feed" href="https://www.cars24.com/blog/feed/">
    <link rel="alternate" type="application/rss+xml" title="All About Buying &amp; Selling of Used Cars, New Car Launches » Comments Feed" href="https://www.cars24.com/blog/comments/feed/">
    <link rel="alternate" type="application/rss+xml" title="All About Buying &amp; Selling of Used Cars, New Car Launches » 10 Most Expensive Cars in the World in 2022 Comments Feed" href="https://www.cars24.com/blog/10-most-expensive-cars-in-the-world/feed/">
    <style type="text/css">
    </style>
    <link rel="stylesheet" id="wp-block-library-css" href="https://www.cars24.com/blog/wp-includes/css/dist/block-library/style.min.css?ver=5.5.1" media="all">
    <link rel="stylesheet" id="wp-block-library-theme-css" href="https://www.cars24.com/blog/wp-includes/css/dist/block-library/theme.min.css?ver=5.5.1" media="all">
    <link rel="stylesheet" id="wpos-slick-style-css" href="https://www.cars24.com/blog/wp-content/plugins/wp-trending-post-slider-and-widget/assets/css/slick.css?ver=1.3.1" media="all">
    <link rel="stylesheet" id="wtpsw-public-style-css" href="https://www.cars24.com/blog/wp-content/plugins/wp-trending-post-slider-and-widget/assets/css/wtpsw-public.css?ver=1.3.1" media="all">
    <link rel="stylesheet" id="twentyseventeen-fonts-css" href="https://fonts.googleapis.com/css?family=Libre+Franklin%3A300%2C300i%2C400%2C400i%2C600%2C600i%2C800%2C800i&amp;subset=latin%2Clatin-ext" media="all">
    <link rel="stylesheet" id="style-css" href="https://www.cars24.com/blog/wp-content/themes/cars24/style.css?ver=2.6" media="all">
    <link rel="stylesheet" id="heateor_sss_frontend_css-css" href="https://www.cars24.com/blog/wp-content/plugins/sassy-social-share/public/css/sassy-social-share-public.css?ver=3.2.28" media="all">
    <link rel="stylesheet" id="heateor_sss_sharing_default_svg-css" href="https://www.cars24.com/blog/wp-content/plugins/sassy-social-share/admin/css/sassy-social-share-svg.css?ver=3.2.28" media="all">
    <link rel="stylesheet" id="wp-paginate-css" href="https://www.cars24.com/blog/wp-content/plugins/wp-paginate/css/wp-paginate.css?ver=3.0.5" media="screen">
    <!--[if lt IE 9]>
<script  src='https://www.cars24.com/blog/wp-content/themes/cars24/assets/js/html5.js?ver=3.7.3' id='html5-js'></script>
<![endif]-->
    <script src="https://www.cars24.com/blog/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp" id="jquery-core-js" type="text/javascript"></script>
    <link rel="https://api.w.org/" href="https://www.cars24.com/blog/wp-json/">
    <link rel="alternate" type="application/json" href="https://www.cars24.com/blog/wp-json/wp/v2/posts/105515">
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.cars24.com/blog/xmlrpc.php?rsd">
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.cars24.com/blog/wp-includes/wlwmanifest.xml">
    <meta name="generator" content="WordPress 5.5.1">
    <link rel="shortlink" href="https://www.cars24.com/blog/?p=105515">
    <link rel="alternate" type="application/json+oembed" href="https://www.cars24.com/blog/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.cars24.com%2Fblog%2F10-most-expensive-cars-in-the-world%2F">
    <link rel="alternate" type="text/xml+oembed" href="https://www.cars24.com/blog/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.cars24.com%2Fblog%2F10-most-expensive-cars-in-the-world%2F&amp;format=xml">
    <link rel="pingback" href="https://www.cars24.com/blog/xmlrpc.php">
    <meta http-equiv="origin-trial" content="A727AcAeLCei/ZogJHBlJUS63SxP6AeIROo7qXrkjrxkoxBu0eSSmypAHmGYwk4HjBMQp5nxCFODzfVnUIe31AQAAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjg4MDgzMTk5LCJpc1RoaXJkUGFydHkiOnRydWV9">
    <script type="text/javascript" async="" src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/941242478/?random=1679809043811&amp;cv=11&amp;fst=1679809043811&amp;bg=ffffff&amp;guid=ON&amp;async=1&amp;gtm=45He33m0&amp;u_w=1536&amp;u_h=864&amp;url=https%3A%2F%2Fwww.cars24.com%2Fblog%2F10-most-expensive-cars-in-the-world%2F&amp;hn=www.googleadservices.com&amp;frm=0&amp;tiba=10%20Most%20Expensive%20Cars%20in%20the%20World%20in%202022&amp;auid=2122794151.1679809044&amp;uaa=x86&amp;uab=64&amp;uafvl=Microsoft%2520Edge%3B111.0.1661.44%7CNot(A%253ABrand%3B8.0.0.0%7CChromium%3B111.0.5563.64&amp;uamb=0&amp;uap=Windows&amp;uapv=14.0.0&amp;uaw=0&amp;rfmt=3&amp;fmt=4"></script>
    <script async="" src="https://static.hotjar.com/c/hotjar-2445077.js?sv=6"></script>
    <link href="https://chatbot.cars24.com/static/css/main.4a8f331a.css" type="text/css" rel="stylesheet" media="screen,print">
    <script src="https://bat.bing.com/p/action/5065002.js" type="text/javascript" async="" data-ueto="ueto_4db329654c"></script>
    <script async="" src="https://script.hotjar.com/modules.936575bc1767492884db.js" charset="utf-8"></script>
</head>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style>
    img,
    li,
    input,
    textarea {
        transition: transform 2s;
    }
    *{
        padding: 2px;
        margin: 3px;
    }
</style>

<script>
    $(document).ready(function() {
        $("input").focus(function() {
            $(this).css("background-color", "yellow");
        });
        $("input").blur(function() {
            $(this).css("background-color", "lightgray");
        });
        $("input").change(function() {
            $("#p3").html("input changed value is : " + $(this).val());
        });
        $("form").submit(function() {
            alert("Submitted");
        });

        $("li,img,input,textarea").mouseenter(function() {
            $(this).css("transform", "scale(1.1)");
            $(this).css("background-color", "green");
            $(this).css("color", "red");
        });

        $("img,input,textarea").mouseleave(function() {
            $(this).css("transform", "scale(1)");
            $(this).css("background-color", "white");
            $(this).css("color", "black");
        });
        $("li").mouseleave(function() {
            $(this).css("transform", "scale(1)");
            $(this).css("background-color", "");
            $(this).css("color", "black");
        });
        $("input[type-submit]").mouseenter(function() {
            $(this).css("transform", "scale(1.1)");
        });
        $("input[type-submit]").mouseleave(function() {
            $(this).css("transform", "scale(1)");
        });
        $('h1').mouseenter(function() {
            $(this).css("backgroundcolor", "yellow");
            $(this).css("color", "blue");
        });
        $('h1').mouseleave(function() {
            $(this).css("backgroundcolor", "White");
            $(this).css("color", "black");
        });


        $('h3').mouseenter(function() {
            $(this).css("transform", "scale(1)");
            $(this).css("backgroundcolor", "aqua");
            $(this).css("color", "red");
        });
        $('h3').mouseleave(function() {
            $(this).css("transform", "scale(1)");
            $(this).css("backgroundcolor", "White");
            $(this).css("color", "black");
        });
        $('h2').mouseenter(function() {
            $(this).css("backgroundcolor", "yellow");
            $(this).css("color", "red");
        });
        $('h2').mouseleave(function() {
            $(this).css("backgroundcolor", "White");
            $(this).css("color", "black");
        });





    });
</script>
</head>

<body class="bg-">
    <header class="bg-warning text-danger m-2 ">
        <h1 class="text-center">
            <marquee behavior="scroll" direction="left">The Top 10 Expensive Cars</marquee>
        </h1>
    </header>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top text-white m-2  ">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"> <i class="fa fa-car"></i>logo</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse " id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php"><i class="fa fa-home"></i> Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.php"><i class="fa fa-image"></i> Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="aboutus.php"><i class="fa fa-user"></i> About us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="services.php"><i class="fa fa-list"></i> Services</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="gallery.php" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa fa-image"></i>
                            Gallery
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="gallery.php">Image</a></li>
                            <li><a class="dropdown-item" href="gallery.php">Video</a></li>

                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contactus.php"><i class="fa fa-phone"></i> Contact Us</a>
                    </li>
                </ul>

                <form class="d-flex">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success" type="submit">Search</button>
                </form>
            </div>
        </div>
    </nav>
    <section id="services" class="our services">
        <h1 class="text-center">Our Services</h1>
        <div class="row">
            <div class="card-group">
                <div class="card">
                    <img src="no4.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to
                            additional content. This content is a little bit longer.</p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">Last updated 3 mins ago</small>
                    </div>
                </div>
                <div class="card">
                    <img src="no7.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">This card has supporting text below as a natural lead-in to additional
                            content.</p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">Last updated 3 mins ago</small>
                    </div>
                </div>
                <div class="card">
                    <img src="no10.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to
                            additional content. This card has even longer content than the first to show that equal
                            height action.</p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">Last updated 3 mins ago</small>
                    </div>
                </div>
            </div>
        <section class=" m-10 p-10">

            <div class="side-inner m-10">
                <h3 class="heading">Sell Car at Nearest Branch</h3>
                <div class="outer">
                    <select id="lead-make_id" class="cascade" onchange="if (!window.__cfRLUnblockHandlers) return false; getBrand(this)">
                        <option value="">Brand</option>
                        <option value="21">MARUTI SUZUKI</option>
                        <option value="15">HYUNDAI</option>
                        <option value="14">HONDA</option>
                        <option value="34">TATA</option>
                        <option value="35">TOYOTA</option>
                        <option value="7">CHEVROLET</option>
                        <option value="12">FORD</option>
                        <option value="58">HUMMER</option>
                        <option value="20">MAHINDRA</option>
                        <option value="55">CADILLAC</option>
                        <option value="32">SKODA</option>
                        <option value="36">VOLKSWAGEN</option>
                        <option value="26">NISSAN</option>
                        <option value="29">RENAULT</option>
                        <option value="10">FIAT</option>
                        <option value="24">MERCEDES BENZ</option>
                        <option value="5">BMW</option>
                        <option value="3">AUDI</option>
                        <option value="52">BAJAJ</option>
                        <option value="59">WILLYS</option>
                        <option value="1">ASHOK LEYLAND</option>
                        <option value="2">ASTON MARTIN</option>
                        <option value="4">BENTLEY</option>
                        <option value="6">BUGATTI</option>
                        <option value="61">CITROEN</option>
                        <option value="49">CRYSLER</option>
                        <option value="40">DAEWOO</option>
                        <option value="8">DATSUN</option>
                        <option value="43">DC</option>
                        <option value="53">EICHER</option>
                        <option value="9">FERRARI</option>
                        <option value="11">FORCE MOTORS</option>
                        <option value="13">HINDUSTAN MOTORS</option>
                        <option value="16">ICML</option>
                        <option value="42">ISUZU</option>
                        <option value="17">JAGUAR</option>
                        <option value="41">Jeep</option>
                        <option value="51">KIA</option>
                        <option value="18">LAMBORGHINI</option>
                        <option value="19">LANDROVER</option>
                        <option value="38">MAHINDRA RENAULT</option>
                        <option value="22">MASERATI</option>
                        <option value="23">MAYBACH</option>
                        <option value="50">MG</option>
                        <option value="25">MITSUBISHI</option>
                        <option value="39">OPEL</option>
                        <option value="45">Peugot</option>
                        <option value="27">PORSCHE</option>
                        <option value="28">PREMIER</option>
                        <option value="30">ROLLS ROYCE</option>
                        <option value="60">ROVAR</option>
                        <option value="31">SAN</option>
                        <option value="57">SMPIL</option>
                        <option value="33">SSANGYONG</option>
                        <option value="44">SUBARU</option>
                        <option value="37">VOLVO</option>
                    </select>
                    <select id="lead-model_id" class="modelval" onchange="if (!window.__cfRLUnblockHandlers) return false; getmodel(this)">
                        <option value="">Model</option>
                        <option value="2">2010</option>
                        <option value="3">2011</option>
                        <option value="4">2012</option>
                        <option value="5">2013</option>
                        <option value="6">2014</option>
                        <option value="7">2015</option>
                        <option value="8">2016</option>
                        <option value="9">2017</option>
                        <option value="10">2018</option>
                        <option value="11">2019</option>
                        <option value="12">2020</option>
                        <option value="13">2021</option>
                        <option value="14">2022</option>
                        <option value="15">2023</option>
                    </select>
                    <select id="lead-model_id" class="yeaval" onchange="if (!window.__cfRLUnblockHandlers) return false; getYearrval(this)">
                        <option value="1">Year</option>
                        <option value="2">2010</option>
                        <option value="3">2011</option>
                        <option value="4">2012</option>
                        <option value="5">2013</option>
                        <option value="6">2014</option>
                        <option value="7">2015</option>
                        <option value="8">2016</option>
                        <option value="9">2017</option>
                        <option value="10">2018</option>
                        <option value="11">2019</option>
                        <option value="12">2020</option>
                        <option value="13">2021</option>
                        <option value="14">2022</option>
                        <option value="15">2023</option>
                    </select>
                    <select id="lead-model_id" class="varient" onchange="if (!window.__cfRLUnblockHandlers) return false; getvariant(this)">
                        <option value="">Variant</option>
                    </select>
                    <select id="lead-model_id" class="carregstate" onchange="if (!window.__cfRLUnblockHandlers) return false; changeState(this)">
                        <option value="">Car Reg. State</option>
                        <option value="1">DL - Delhi</option>
                        <option value="2">HR - Haryana</option>
                        <option value="3">UP - Uttar Pradesh</option>
                        <option value="4">PB - Punjab</option>
                        <option value="5">CH - Chandigarh</option>
                        <option value="6">WB - West Bengal</option>
                        <option value="7">HP - Himachal Pradesh</option>
                        <option value="8">JK - Jammu and Kashmir</option>
                        <option value="9">UK - Uttarakhand</option>
                        <option value="10">GJ - Gujarat</option>
                        <option value="11">RJ - Rajasthan</option>
                        <option value="14">MH - Maharashtra</option>
                        <option value="15">GA - Goa</option>
                        <option value="16">MP - Madhya Pradesh</option>
                        <option value="17">CG - Chhattisgarh</option>
                        <option value="18">AP - Andhra Pradesh</option>
                        <option value="19">KA - Karnataka</option>
                        <option value="20">TN - Tamil Nadu</option>
                        <option value="21">PY - Puducherry</option>
                        <option value="22">KL - Kerala</option>
                        <option value="24">AS - Assam</option>
                        <option value="27">OD - Odisha</option>
                        <option value="34">BR - Bihar</option>
                        <option value="35">JH - Jharkhand</option>
                        <option value="36">TS - Telangana</option>
                    </select>
                    <select id="lead-model_id" class="kmdriven" onchange="if (!window.__cfRLUnblockHandlers) return false; kmdriven(this)">
                        <option value="">Km Driven</option>
                        <option value="5000">Up to 10000 km</option>
                        <option value="15000">10000 - 20000 km</option>
                        <option value="30000">20000 - 40000 km</option>
                        <option value="50000">40000 - 60000 km</option>
                        <option value="80000">60000 - 100000 km</option>
                        <option value="120000">Above 100000 km</option>
                    </select>
                    <input type="text" id="inputsearchform" name="phone" class="phone" onkeyup="if (!window.__cfRLUnblockHandlers) return false; checkPhone(this)" placeholder="Mobile No.">
                    <span class="showerror"></span>
                    <span class="showerror1" style="color:green;font-size:13px;"></span>
                    <button id="inputsearchform" class="btn sibmitb submit-legend" onclick="if (!window.__cfRLUnblockHandlers) return false; submitform()" name="submit">START CAR EVALUATION</button>
                </div>
            </div>
        </section>

    </section>
    <footer class="bg-dark text-white m-2 pb-2 sticky-bottom">
        <h1 class="text-center ">Footer</h1>
        <p class="text-center"> Developed by akashtangadkar @2023. All rights are Reserved <i class="fa fa-copyright"></i>
        </p>
    </footer>
    <script>
        function checkvalidation() {
            var name = document.getElementById('name').value;
            var email = document.getElementById("email").value;
            var contact = document.getElementById("contact").value;
            var message = document.getElementById("message").value;

            if (name == '') {
                alert('Please Enter Your Name');
                document.getElementById('name').focus();
                return false;

            } else if (email == '') {
                alert('Please Enter Email Id');
                document.getElementById('email').focus();
                return false;

            } else if (contact == '') {
                alert('Please Enter Your Contact No.');
                document.getElementById('contact').focus();
                return false;

            } else if (message == '') {
                alert('Please Enter Your Comment');
                document.getElementById('message').focus();
                return false;

            } else {
                alert('Your inquiry is Succesfull')
                return true;
            }
        }
    </script>

</body>

</html>