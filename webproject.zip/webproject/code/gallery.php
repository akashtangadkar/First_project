<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The top 10 Expensive Cars</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script>


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        img,li,input,textarea{
            transition:transform 2s;
        }

    </style>

    <script>
        $(document).ready(function () {
            $("input").focus(function () {
                $(this).css("background-color", "yellow");
            });
            $("input").blur(function () {
                $(this).css("background-color", "lightgray");
            });
            $("input").change(function () {
                $("#p3").html("input changed value is : " + $(this).val());
            });
            $("form").submit(function () {
                alert("Submitted");
            });

            $("li,img,input,textarea").mouseenter(function () {
                $(this).css("transform", "scale(1.1)");
                $(this).css("background-color", "green");
                $(this).css("color", "red");
            });

            $("img,input,textarea").mouseleave(function () {
                $(this).css("transform", "scale(1)");
                $(this).css("background-color", "white");
                $(this).css("color", "black");
            });
            $("li").mouseleave(function () {
                $(this).css("transform", "scale(1)");
                $(this).css("background-color", "");
                $(this).css("color", "black");
            });
            $("input[type-submit]").mouseenter(function () {
                $(this).css("transform", "scale(1.1)");
            });
            $("input[type-submit]").mouseleave(function () {
                $(this).css("transform", "scale(1)");
            });
            $('h1').mouseenter(function(){
                $(this).css("backgroundcolor","yellow");
                $(this).css("color", "blue");
            });
            $('h1').mouseleave(function(){
                $(this).css("backgroundcolor","White");
                $(this).css("color", "black");
            });


            $('h3').mouseenter(function(){
                $(this).css("transform","scale(1.1)");
                $(this).css("backgroundcolor","aqua");
                $(this).css("color", "red");
            });
            $('h3').mouseleave(function(){
                $(this).css("transform","scale(1)");
                $(this).css("backgroundcolor","White");
                $(this).css("color", "black");
            });
            $('h2').mouseenter(function(){
                $(this).css("backgroundcolor","yellow");
                $(this).css("color", "red");
            });
            $('h2').mouseleave(function(){
                $(this).css("backgroundcolor","White");
                $(this).css("color", "black");
            });





        });


    </script>
</head>

<body class="bg-">
    <header class="bg-warning text-danger m-2 ">
        <h1 class="text-center">
            <marquee behavior="scroll" direction="left">The Top 10 Expensive Cars</marquee>
        </h1>
    </header>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top text-white m-2  ">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"> <i class="fa fa-car"></i>logo</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse " id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php"><i class="fa fa-home"></i> Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.php"><i class="fa fa-image"></i> Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="aboutus.php"><i class="fa fa-user"></i> About us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="services.php"><i class="fa fa-list"></i> Services</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="gallery.php" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false"><i class="fa fa-image"></i>
                            Gallery
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="gallery.php">Image</a></li>
                            <li><a class="dropdown-item" href="gallery.php">Video</a></li>

                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contactus.php"><i class="fa fa-phone"></i> Contact Us</a>
                    </li>
                </ul>

                <form class="d-flex">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success" type="submit">Search</button>
                </form>
            </div>
        </div>
    </nav>
<section id="Gallery" class="m-2">

<h1 class="text-center">Gallery</h1>
<div class="row">
    <div class="col-6 col-lg-3 ">
        <img class="m-1 img-fluid" src="car3.jpg" alt="">

    </div>
    <div class="col-6 col-lg-3 ">
        <img class="m-1 img-fluid" src="car2.jpg" alt="">

    </div>
    <div class="col-6 col-lg-3 ">
        <img class="m-1 img-fluid" src="car4.jpg" alt="">

    </div>
    <div class="col-6 col-lg-3 ">
        <img class="m-1 img-fluid" src="no9.jpg" alt="">

    </div>
</div>
<div class="row">
    <div class="col-6 col-lg-3 ">
        <img class="m-1 img-fluid" src="no1.jpg" alt="">

    </div>
    <div class="col-6 col-lg-3 ">
        <img class="m-1 img-fluid" src="no2.jpg" alt="">

    </div>
    <div class="col-6 col-lg-3 ">
        <img class="m-1 img-fluid" src="no3.jpg" alt="">

    </div>
    <div class="col-6 col-lg-3">
        <img class="m-1 img-fluid" src="no4.jpg" alt="">

    </div>
</div>
<div class="row">
    <div class="col-6 col-lg-3 ">
        <img class="m-1 img-fluid" src="no5.jpg" alt="">

    </div>
    <div class="col-6 col-lg-3 ">
        <img class="m-1 img-fluid" src="no6.jpg" alt="">

    </div>
    <div class="col-6 col-lg-3 ">
        <img class="m-1 img-fluid" src="no7.jpg" alt="">

    </div>
    <div class="col-6 col-lg-3 ">
        <img class="m-1 img-fluid" src="no8.jpg" alt="">

    </div>
</div>
</section>
<section id="videogallery">
<h1 class="text-center">Video Gallery</h1>
<div class="row">
    <div class="col-12 col-lg-3">
        <video controls src=""></video>

    </div>
    <div class="col-12 col-lg-3">
        <video controls src=""></video>

    </div>
    <div class="col-12 col-lg-3">
        <video controls src=""></video>

    </div>
    <div class="col-12 col-lg-3">
        <video controls src=""></video>

    </div>
</div>


</section>
<footer class="bg-dark text-white m-2 pb-2 sticky-bottom">
        <h1 class="text-center ">Footer</h1>
        <p class="text-center"> Developed by akashtangadkar @2023. All rights are Reserved <i
                class="fa fa-copyright"></i>
        </p>
    </footer>
    <script>
        function checkvalidation() {
            var name = document.getElementById('name').value;
            var email = document.getElementById("email").value;
            var contact = document.getElementById("contact").value;
            var message = document.getElementById("message").value;

            if (name == '') {
                alert('Please Enter Your Name');
                document.getElementById('name').focus();
                return false;

            }
            else if (email == '') {
                alert('Please Enter Email Id');
                document.getElementById('email').focus();
                return false;

            }
            else if (contact == '') {
                alert('Please Enter Your Contact No.');
                document.getElementById('contact').focus();
                return false;

            }
            else if (message == '') {
                alert('Please Enter Your Comment');
                document.getElementById('message').focus();
                return false;

            }
            else {
                alert('Your inquiry is Succesfull')
                return true;
            }
        }
    </script>
    
</body>
</html>