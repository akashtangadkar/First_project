<?php require_once('navbar.php'); ?>
<section class="p-5 bg-light" id="contactus">
        <h1 class="text-center">Contact Us</h1>
        <div class="row">
            <div class="col p-3">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3772.395801718788!2d73.94147791437571!3d19.00227295922492!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bdd3131f9536e2b%3A0xe686c788abf87944!2sSmart%20Tech%20Software%20Solution%20Manchar!5e0!3m2!1sen!2sin!4v1676530924391!5m2!1sen!2sin"
                    width="100%" height="400" style="border:5;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
            <div class="col p-3 bg-white rounded-3">
                <h1 class="text-center">Contact Us</h1>
                <?php
                include_once('conn.php');
                if(isset($_POST['register'])) {
                    $fname=trim($_POST['fname']);
                    $lname=trim($_POST['lname']);
                    $emailid=trim($_POST['emailid']);
                    $mobile=trim($_POST['mobile']);
                    $message=trim($_POST['message']);
                    $currentdatetime=date('Y-m-d h:i:s');
                    $sql_query="insert into tblcontactus(fname,lname,emailid,mobile,message,insertdatetime) values('$fname','$lname','$emailid','$mobile','$message','$currentdatetime')";

                    mysqli_query($con,$sql_query);
                    
                    echo "<script> alert('Contact Us Data Save Successfully...!'); </script>";
                }
                ?>
                <form method="post" action="" role="form">
                    <div class="messages"></div>
                    <div class="controls">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="form_name">Firstname <span class="text-danger">*</span></label>
                                    <input id="fname" type="text" name="fname" class="form-control" placeholder="Firstname" required="">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="form_lastname">Last Name<span class="text-danger">*</span></label>
                                    <input id="lname" type="text" name="lname" class="form-control" placeholder="Lastname" required="">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="form_email">Email <span class="text-danger">*</span></label>
                                    <input id="emailid" type="email" name="emailid" class="form-control" placeholder="email" required="">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="form_phone">Mobile</label>
                                    <input id="mobile" type="tel" name="mobile" class="form-control" placeholder="phone">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group mb-2">
                                    <label for="form_message">Message <span class="text-danger">*</span></label>
                                    <textarea id="message" name="message" class="form-control" placeholder="Message" rows="4" required="required"></textarea>
                                </div>
                            </div>
                            <div class="col-md-12 mt-2">
                                <input type="submit" name="register" class="btn btn-success btn-send" value="Send message">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php require_once('footer.php'); ?>
