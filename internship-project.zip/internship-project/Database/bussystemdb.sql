-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2023 at 09:28 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bussystemdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblaboutus`
--

CREATE TABLE `tblaboutus` (
  `idaboutus` int(10) NOT NULL,
  `companyname` varchar(100) NOT NULL,
  `companydesc` longtext NOT NULL,
  `companylogo` varchar(500) NOT NULL,
  `insertdatetime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblaboutus`
--

INSERT INTO `tblaboutus` (`idaboutus`, `companyname`, `companydesc`, `companylogo`, `insertdatetime`) VALUES
(5, 'Smart Tech Manchar', 'Smart Tech Software Solution is one of The Best Professional Web Designing, Web Development, Mobile Application Development, and Digital Marketing companies in Manchar Pune 410503 with more than 4 years of experience in designing and developing web applications, and has completed more than 50+ projects for clients around Maharashtra. Our main objective is to Design and Develop the website/app based on the Clients requirements which helps them succeed in their business targets. Smart Tech Software Solution also provides Digital Marketing Services for your Business. We not only build your website but also provide Search Engine Optimization Services, Social Media Marketing, PPC management, Facebook, and Google Ads Service. We help you reach thousands of potential customers for your business through online mediums. We provide Digital Marketing services mainly in the field of E-commerce, Businesses, Education. We are among the few companies who can provide the Best Services is based on the Clients requirements at affordable prices. We are providing the best web solution to small and medium businesses at a very low price. We understand the uniqueness of your site and your business needs. Hence, Smart Tech Software Solution be your first step towards achieving the desired success which you have always dreamed of.', 'smart-tech-software-manchar (1).png', '2023-03-25 01:13:06');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactus`
--

CREATE TABLE `tblcontactus` (
  `idcontact` int(10) NOT NULL,
  `fname` varchar(32) NOT NULL,
  `lname` varchar(32) NOT NULL,
  `emailid` varchar(64) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `message` longtext NOT NULL,
  `insertdatetime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblcontactus`
--

INSERT INTO `tblcontactus` (`idcontact`, `fname`, `lname`, `emailid`, `mobile`, `message`, `insertdatetime`) VALUES
(3, 'sdfghj', 'asdfghj', 'zxcv@gmail.com', '7788995544', 'Message Data', '2023-03-20 02:42:25'),
(4, 'SWapnil', 'Bheke', 'bh@gmail.com', '7788995544', 'hii hello', '2023-03-21 01:35:50');

-- --------------------------------------------------------

--
-- Table structure for table `tblgallery`
--

CREATE TABLE `tblgallery` (
  `idgallery` int(10) NOT NULL,
  `gallerytype` varchar(250) NOT NULL,
  `galleryfile` varchar(250) NOT NULL,
  `insertdatetime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblgallery`
--

INSERT INTO `tblgallery` (`idgallery`, `gallerytype`, `galleryfile`, `insertdatetime`) VALUES
(3, 'Image', 'login2.png', '2023-03-25 11:52:03'),
(4, 'Image', 'login.png', '2023-03-25 11:52:13'),
(5, 'Video', 'login2.png', '2023-03-25 11:52:36'),
(6, 'Documentry', 'new_york.jpg', '2023-03-25 11:54:08');

-- --------------------------------------------------------

--
-- Table structure for table `tblservices`
--

CREATE TABLE `tblservices` (
  `idservice` int(10) NOT NULL,
  `servicename` varchar(100) NOT NULL,
  `servicedesc` longtext NOT NULL,
  `serviceimage` varchar(500) NOT NULL,
  `insertdatetime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblservices`
--

INSERT INTO `tblservices` (`idservice`, `servicename`, `servicedesc`, `serviceimage`, `insertdatetime`) VALUES
(3, 'Service 1', 'Service Details', 'Gold_coin_icon.png', '2023-03-31 09:51:38'),
(5, 'Service 2', 'Service 2 Details', '250-2505761_gudi-padwa-greeting-card-creative-gudi-padwa-png.png', '2023-03-31 09:52:04'),
(6, 'Service 3', 'Service 3 Details', '599d9a71260043.Y3JvcCwxNTU0LDEyMTUsMCwxMTE.png', '2023-03-31 09:52:29'),
(7, 'Service 4', 'Service 4 Details', 'png-lawyer-logo-zeevector.com_.png', '2023-03-31 09:52:52');

-- --------------------------------------------------------

--
-- Table structure for table `tblslider`
--

CREATE TABLE `tblslider` (
  `idslider` int(10) NOT NULL,
  `sliderdata` varchar(255) NOT NULL,
  `logo` varchar(256) NOT NULL,
  `insertdatetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblslider`
--

INSERT INTO `tblslider` (`idslider`, `sliderdata`, `logo`, `insertdatetime`) VALUES
(13, 'Welcome To Smart Tech Software Solution Manchar', 'new_york.jpg', '2023-03-25 01:00:50'),
(14, 'Welcome To Smart Tech Software Solution Manchar', 'hongkong1081704.jpg', '2023-03-25 01:00:54'),
(16, 'Welcome To Smart Tech Software Solution Manchar', 'beautiful-landscape-with-clear-sky_23-2149721820.jpg', '2023-03-25 01:00:59');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE `tbluser` (
  `iduser` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`iduser`, `username`, `password`) VALUES
(1, 'admin', 'admin1'),
(2, 'Swapnil', '123456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblaboutus`
--
ALTER TABLE `tblaboutus`
  ADD PRIMARY KEY (`idaboutus`);

--
-- Indexes for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  ADD PRIMARY KEY (`idcontact`);

--
-- Indexes for table `tblgallery`
--
ALTER TABLE `tblgallery`
  ADD PRIMARY KEY (`idgallery`);

--
-- Indexes for table `tblservices`
--
ALTER TABLE `tblservices`
  ADD PRIMARY KEY (`idservice`);

--
-- Indexes for table `tblslider`
--
ALTER TABLE `tblslider`
  ADD PRIMARY KEY (`idslider`);

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`iduser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblaboutus`
--
ALTER TABLE `tblaboutus`
  MODIFY `idaboutus` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  MODIFY `idcontact` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblgallery`
--
ALTER TABLE `tblgallery`
  MODIFY `idgallery` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblservices`
--
ALTER TABLE `tblservices`
  MODIFY `idservice` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblslider`
--
ALTER TABLE `tblslider`
  MODIFY `idslider` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `iduser` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
