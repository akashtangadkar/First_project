<?php require_once('navbar.php'); ?>
<?php require_once('conn.php'); ?>
<section class="p-5 bg-light" id="services">
        <h1 class="text-center">Services</h1>
        <hr>
        <div class="row mb-3">
        <?php 
            $query="select * from tblservices";
            $result=mysqli_query($con,$query);
            while($row=mysqli_fetch_assoc($result)){
            ?>
            <div class="col-6 col-md-3 col-lg-3 ">
                <div class="card">
                    <img src="admin/services/<?php echo $row['serviceimage']; ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $row['servicename']; ?></h5>
                        <p class="card-text"><?php echo $row['servicedesc']; ?></p>
                     </div>
                </div>
            </div>
            <?php } ?> 
        </div>
    </section>
    <head>
    <style type="text/css">
        .heateor_sss_horizontal_sharing .heateorSssSharing,
        .heateor_sss_standard_follow_icons_container .heateorSssSharing {
            background-color: #000000;
            color: #fff;
            border-width: 0px;
            border-style: solid;
            border-color: transparent;
        }

        .heateor_sss_horizontal_sharing .heateorSssTCBackground {
            color: #666;
        }

        .heateor_sss_horizontal_sharing .heateorSssSharing:hover,
        .heateor_sss_standard_follow_icons_container .heateorSssSharing:hover {
            border-color: transparent;
        }

        .heateor_sss_vertical_sharing .heateorSssSharing,
        .heateor_sss_floating_follow_icons_container .heateorSssSharing {
            background-color: #000;
            color: #fff;
            border-width: 0px;
            border-style: solid;
            border-color: transparent;
        }

        .heateor_sss_vertical_sharing .heateorSssTCBackground {
            color: #666;
        }

        .heateor_sss_vertical_sharing .heateorSssSharing:hover,
        .heateor_sss_floating_follow_icons_container .heateorSssSharing:hover {
            border-color: transparent;
        }

        @media screen and (max-width:783px) {
            .heateor_sss_vertical_sharing {
                display: none !important
            }
        }

        div.heateor_sss_mobile_footer {
            display: none;
        }

        @media screen and (max-width:783px) {
            i.heateorSssTCBackground {
                background-color: white !important
            }

            div.heateor_sss_bottom_sharing {
                width: 100% !important;
                left: 0 !important;
            }

            div.heateor_sss_bottom_sharing li {
                width: 33.333333333333% !important;
            }

            div.heateor_sss_bottom_sharing .heateorSssSharing {
                width: 100% !important;
            }

            div.heateor_sss_bottom_sharing div.heateorSssTotalShareCount {
                font-size: 1em !important;
                line-height: 24.5px !important
            }

            div.heateor_sss_bottom_sharing div.heateorSssTotalShareText {
                font-size: .7em !important;
                line-height: 0px !important
            }

            div.heateor_sss_mobile_footer {
                display: block;
                height: 35px;
            }

            .heateor_sss_bottom_sharing {
                padding: 0 !important;
                display: block !important;
                width: auto !important;
                bottom: -2px !important;
                top: auto !important;
            }

            .heateor_sss_bottom_sharing .heateor_sss_square_count {
                line-height: inherit;
            }

            .heateor_sss_bottom_sharing .heateorSssSharingArrow {
                display: none;
            }

            .heateor_sss_bottom_sharing .heateorSssTCBackground {
                margin-right: 1.1em !important
            }
        }
    </style>
    </head>
    <section class=" m-10 p-10">

            <div class="side-inner m-10">
                <h3 class="heading">Sell Car at Nearest Branch</h3>
                <div class="outer">
                    <select id="lead-make_id" class="cascade" onchange="if (!window.__cfRLUnblockHandlers) return false; getBrand(this)">
                        <option value="">Brand</option>
                        <option value="21">MARUTI SUZUKI</option>
                        <option value="15">HYUNDAI</option>
                        <option value="14">HONDA</option>
                        <option value="34">TATA</option>
                        <option value="35">TOYOTA</option>
                        <option value="7">CHEVROLET</option>
                        <option value="12">FORD</option>
                        <option value="58">HUMMER</option>
                        <option value="20">MAHINDRA</option>
                        <option value="55">CADILLAC</option>
                        <option value="32">SKODA</option>
                        <option value="36">VOLKSWAGEN</option>
                        <option value="26">NISSAN</option>
                        <option value="29">RENAULT</option>
                        <option value="10">FIAT</option>
                        <option value="24">MERCEDES BENZ</option>
                        <option value="5">BMW</option>
                        <option value="3">AUDI</option>
                        <option value="52">BAJAJ</option>
                        <option value="59">WILLYS</option>
                        <option value="1">ASHOK LEYLAND</option>
                        <option value="2">ASTON MARTIN</option>
                        <option value="4">BENTLEY</option>
                        <option value="6">BUGATTI</option>
                        <option value="61">CITROEN</option>
                        <option value="49">CRYSLER</option>
                        <option value="40">DAEWOO</option>
                        <option value="8">DATSUN</option>
                        <option value="43">DC</option>
                        <option value="53">EICHER</option>
                        <option value="9">FERRARI</option>
                        <option value="11">FORCE MOTORS</option>
                        <option value="13">HINDUSTAN MOTORS</option>
                        <option value="16">ICML</option>
                        <option value="42">ISUZU</option>
                        <option value="17">JAGUAR</option>
                        <option value="41">Jeep</option>
                        <option value="51">KIA</option>
                        <option value="18">LAMBORGHINI</option>
                        <option value="19">LANDROVER</option>
                        <option value="38">MAHINDRA RENAULT</option>
                        <option value="22">MASERATI</option>
                        <option value="23">MAYBACH</option>
                        <option value="50">MG</option>
                        <option value="25">MITSUBISHI</option>
                        <option value="39">OPEL</option>
                        <option value="45">Peugot</option>
                        <option value="27">PORSCHE</option>
                        <option value="28">PREMIER</option>
                        <option value="30">ROLLS ROYCE</option>
                        <option value="60">ROVAR</option>
                        <option value="31">SAN</option>
                        <option value="57">SMPIL</option>
                        <option value="33">SSANGYONG</option>
                        <option value="44">SUBARU</option>
                        <option value="37">VOLVO</option>
                    </select>
                    <select id="lead-model_id" class="modelval" onchange="if (!window.__cfRLUnblockHandlers) return false; getmodel(this)">
                        <option value="">Model</option>
                        <option value="2">2010</option>
                        <option value="3">2011</option>
                        <option value="4">2012</option>
                        <option value="5">2013</option>
                        <option value="6">2014</option>
                        <option value="7">2015</option>
                        <option value="8">2016</option>
                        <option value="9">2017</option>
                        <option value="10">2018</option>
                        <option value="11">2019</option>
                        <option value="12">2020</option>
                        <option value="13">2021</option>
                        <option value="14">2022</option>
                        <option value="15">2023</option>
                    </select>
                    <select id="lead-model_id" class="yeaval" onchange="if (!window.__cfRLUnblockHandlers) return false; getYearrval(this)">
                        <option value="1">Year</option>
                        <option value="2">2010</option>
                        <option value="3">2011</option>
                        <option value="4">2012</option>
                        <option value="5">2013</option>
                        <option value="6">2014</option>
                        <option value="7">2015</option>
                        <option value="8">2016</option>
                        <option value="9">2017</option>
                        <option value="10">2018</option>
                        <option value="11">2019</option>
                        <option value="12">2020</option>
                        <option value="13">2021</option>
                        <option value="14">2022</option>
                        <option value="15">2023</option>
                    </select>
                    <select id="lead-model_id" class="varient" onchange="if (!window.__cfRLUnblockHandlers) return false; getvariant(this)">
                        <option value="">Variant</option>
                    </select>
                    <select id="lead-model_id" class="carregstate" onchange="if (!window.__cfRLUnblockHandlers) return false; changeState(this)">
                        <option value="">Car Reg. State</option>
                        <option value="1">DL - Delhi</option>
                        <option value="2">HR - Haryana</option>
                        <option value="3">UP - Uttar Pradesh</option>
                        <option value="4">PB - Punjab</option>
                        <option value="5">CH - Chandigarh</option>
                        <option value="6">WB - West Bengal</option>
                        <option value="7">HP - Himachal Pradesh</option>
                        <option value="8">JK - Jammu and Kashmir</option>
                        <option value="9">UK - Uttarakhand</option>
                        <option value="10">GJ - Gujarat</option>
                        <option value="11">RJ - Rajasthan</option>
                        <option value="14">MH - Maharashtra</option>
                        <option value="15">GA - Goa</option>
                        <option value="16">MP - Madhya Pradesh</option>
                        <option value="17">CG - Chhattisgarh</option>
                        <option value="18">AP - Andhra Pradesh</option>
                        <option value="19">KA - Karnataka</option>
                        <option value="20">TN - Tamil Nadu</option>
                        <option value="21">PY - Puducherry</option>
                        <option value="22">KL - Kerala</option>
                        <option value="24">AS - Assam</option>
                        <option value="27">OD - Odisha</option>
                        <option value="34">BR - Bihar</option>
                        <option value="35">JH - Jharkhand</option>
                        <option value="36">TS - Telangana</option>
                    </select>
                    <select id="lead-model_id" class="kmdriven" onchange="if (!window.__cfRLUnblockHandlers) return false; kmdriven(this)">
                        <option value="">Km Driven</option>
                        <option value="5000">Up to 10000 km</option>
                        <option value="15000">10000 - 20000 km</option>
                        <option value="30000">20000 - 40000 km</option>
                        <option value="50000">40000 - 60000 km</option>
                        <option value="80000">60000 - 100000 km</option>
                        <option value="120000">Above 100000 km</option>
                    </select>
                    <input type="text" id="inputsearchform" name="phone" class="phone" onkeyup="if (!window.__cfRLUnblockHandlers) return false; checkPhone(this)" placeholder="Mobile No.">
                    <span class="showerror"></span>
                    <span class="showerror1" style="color:green;font-size:13px;"></span>
                    <button id="inputsearchform" class="btn sibmitb submit-legend" onclick="if (!window.__cfRLUnblockHandlers) return false; submitform()" name="submit">START CAR EVALUATION</button>
                </div>
            </div>
        </section>
<?php require_once('footer.php'); ?>
