<?php require_once('navbar.php'); ?>
<?php require_once('conn.php'); ?>
<section class="p-5 bg-white" id="gallery">
        <h1 class="text-center">Gallery</h1>
        <hr>
        <h3 class="text-center">Images</h3>
        <div class="row mb-3">
        <?php 
            $query="select * from tblgallery where gallerytype='Image'";
            $result=mysqli_query($con,$query);
            while($row=mysqli_fetch_assoc($result)){
            ?>
            <div class="col-6 col-md-3 col-lg-3 p-3">
                <img src="admin/gallery/<?php echo $row['galleryfile'];?>" class="img-fluid img-thumbnail" alt="...">
            </div>
            <?php } ?>
         </div>
        <h3 class="text-center">Videos</h3>
        <div class="row mb-3">
        <?php 
            $query="select * from tblgallery where gallerytype='Video'";
            $result=mysqli_query($con,$query);
            while($row=mysqli_fetch_assoc($result)){
            ?>
            <div class="col-6 col-md-3 col-lg-3 p-3">
                <img src="admin/gallery/<?php echo $row['galleryfile'];?>" class="img-fluid img-thumbnail" alt="...">
            </div>
            <?php } ?>
         </div>
        <h3 class="text-center">Documentry</h3>
        <div class="row mb-3">
        <?php 
            $query="select * from tblgallery where gallerytype='Documentry'";
            $result=mysqli_query($con,$query);
            while($row=mysqli_fetch_assoc($result)){
            ?>
            <div class="col-6 col-md-3 col-lg-3 p-3">
                <img src="admin/gallery/<?php echo $row['galleryfile'];?>" class="img-fluid img-thumbnail" alt="...">
            </div>
            <?php } ?>
         </div>
    </section>
<?php require_once('footer.php'); ?>
