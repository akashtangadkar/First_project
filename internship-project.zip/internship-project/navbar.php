<!DOCTYPE html>
<html lang="en">
<head>
    <title>The Top 10 Expensive Car</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="jquery.min.js"></script>
    <style>
        img,
        li,
        input,
        textarea,
        p,
        .footer {
            transition: transform 2s;
        }
        h1,
        h3 {
            transition: transform 2s;
        }
    </style>
    <script>
        $(document).ready(function() {
            $('h1,h3').not('#aboutimg').mouseenter(function() {
                $(this).css('transform', 'scale(1.5)')
            });
            $('h1,h3').not('#aboutimg').mouseleave(function() {
                $(this).css('transform', 'scale(1)')
            });
            $('img,input[type=submit]').mouseenter(function() {
                $(this).css('transform', 'scale(1.1)')
            });
            $('img,input[type=submit]').mouseleave(function() {
                $(this).css('transform', 'scale(1)')
            });
            $('li,p,.footer,input,textarea').mouseenter(function() {
                $(this).css('transform', 'scale(1.1)');
                $(this).css('font-weight', 'bold');
                $(this).css('color', 'red');
            });
            $('li,p,.footer,input,textarea').mouseleave(function() {
                $(this).css('transform', 'scale(1)');
                $(this).css('font-weight', 'normal');
                $(this).css('color', 'black');
            });
            $('.compname').click(function() {
                $('.pfirst').css('background-color', 'yellow');
                $('.pfirst').toggle(1000);
            });
            $('input,textarea').focus(function() {
                $(this).css('background-color', 'pink');
            });
            $('input,textarea').blur(function() {
                $(this).css('background-color', 'white');
            });
        });
    </script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Company Name & Logo</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.php">Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="services.php">Services</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Gallery
                    </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="gallery.php">Images</a></li>
                            <li><a class="dropdown-item" href="gallery.php">Videos</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="gallery.php">Documentry</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin/index.php" target="_blank">Admin Login</a>
                    </li>
                </ul>
             </div>
        </div>
    </nav>
