<?php 
require_once('navbar.php'); 
require_once('conn.php'); 
?>
    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <?php 
            $query="select * from tblslider";
            $resultsc=mysqli_query($con,$query);
            $b=0;
             while($rows=mysqli_fetch_assoc($resultsc)){ ?>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="<?php echo $b; ?>" <?php if($b==0) { ?> class="active" <?php } ?> aria-current="true" aria-label="Slide <?php echo $b; ?>"></button>
            <?php $b++; } ?>
        </div>
        <div class="carousel-inner">
            <?php 
            $query="select * from tblslider";
            $result=mysqli_query($con,$query);
            $s=1;
            while($row=mysqli_fetch_assoc($result)){  ?>
            <div class="carousel-item <?php if($s==1) { ?> active <?php } ?> ">
                <img src="admin/logo/<?php echo $row['logo']; ?>" class="d-block w-100" alt="Slider-">
                <div class="carousel-caption d-none d-md-block">
                    <h1 class="text-center text-white"><?php echo $row['sliderdata']; ?></h1>
                 </div>
            </div>
            <?php $s++; } ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>
    </div>
    <?php require_once('services.php'); ?>
    <?php require_once('contact.php'); ?>
    <?php require_once('footer.php'); ?>
</body>
</html>