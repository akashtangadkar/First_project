<footer class="bg-dark text-white p-3">
    <h3 class="text-center">Developed by akashtangadkar Pvt Ltd.@2022-2023. All Right Reserved.</h3>
</footer>