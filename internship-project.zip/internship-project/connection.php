<?php
	error_reporting('E_ALL');
    session_start();
	set_time_limit(0);
	date_default_timezone_set('Asia/Kolkata');
    $con=mysqli_connect("localhost","root","","ajax");
 	if(!$con){
		die ("Failed to connect :".mysqli_connect_error());
	}
	mysqli_query($con,"SET NAMES utf8");
?>