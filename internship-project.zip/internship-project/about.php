<?php require_once('navbar.php'); ?>
<?php require_once('conn.php'); ?>
<section class="p-5" id="aboutus">
        <h1 class="text-center">About Us</h1>
        <hr>
        <?php 
        $query="select * from tblaboutus";
        $result=mysqli_query($con,$query);
        while($row=mysqli_fetch_assoc($result)){
        ?>
        <div class="row">
            <div class="col-12 col-md-6 col-lg-6">
                <img src="admin/about/<?php echo $row['companylogo']; ?>" alt="" srcset="" class="img-fluid">
            </div>
            <div class="col-12 col-md-6 col-lg-6">
                <p><?php echo $row['companydesc']; ?></p>
            </div>
        </div>
        <?php } ?>
    </section>
<?php require_once('footer.php'); ?>