<?php 
    include_once('sidebar.php');  
    include_once('conn.php'); 
    if($_GET['idgallery']!=''){
        $query="select * from tblgallery where idgallery='".$_GET['idgallery']."'";
        $result=mysqli_query($con,$query);
        $rowedit=mysqli_fetch_assoc($result);
    }
?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="col-12 mt-2">
        <h1 class="text-center h2">Add Gallery Images</h1>
       </div>
       <form method="post" action="gallerysave.php" role="form" enctype="multipart/form-data">
        <div class="messages"></div>
        <div class="controls">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group mb-2">
                        <label for="form_name">Gallery Type <span class="text-danger">*</span></label>
                         <select id="gallerytype" name="gallerytype" class="form-control" required>
                            <option value="">Select Gallery Type</option>
                            <option value="Image" <?php if($rowedit['gallerytype']=='Image'){ echo "selected"; } ?>>Image</option>
                            <option value="Video" <?php if($rowedit['gallerytype']=='Video'){ echo "selected"; } ?>>Video</option>
                            <option value="Documentry" <?php if($rowedit['gallerytype']=='Documentry'){ echo "selected"; } ?>>Documentry</option>
                        </select>
                    </div>
                </div>
             </div>
             <div class="row">
                <div class="col-md-12">
                    <div class="form-group mb-2">
                        <label for="form_message">Gallery <span class="text-danger">*</span></label>
                        <input type="file" id="galleryfile" name="galleryfile" class="form-control">
                        <input type="hidden" id="galleryfileold" name="galleryfileold" class="form-control" value="<?php echo $rowedit['galleryfile']; ?>">
                        <br>
                        <?php if($_GET['idgallery']!=''){ ?>
                        <img src="gallery<?php echo $rowedit['galleryfile']; ?>" height=50 width=50> 
                        <?php } ?>
                    </div>
                </div>
                <div class="col-md-12 mt-2 text-center">
                    <?php if($_GET['operation']==""){  ?>
                    <input type="submit" name="insert" class="btn btn-success btn-send" value="Save">
                <?php  } else if($_GET['operation']=="update"){  ?>
                    <input type="submit" name="update" class="btn btn-warning btn-send" value="Update">
                <?php  }else if($_GET['operation']=="delete"){ ?>
                    <input type="submit" name="delete" class="btn btn-danger btn-send" value="Delete"> 
                    <?php   } ?>
                    <input type="hidden" name="idgallery" id="idgallery" value="<?php echo $_GET['idgallery']; ?>">
                    <a href="addgallery.php" class="btn btn-info">Refresh</a>
                </div>
            </div>
        </div>
    </form>
    <hr>
       <h3 class="text-center">Gallery List</h3>                    
       <div class="table-responsive">
            <table class="table table-bordered">
                <tr class="bg-dark text-white">
                    <th>Update</th>
                    <th>Delete</th>
                    <th>Sr.No.</th>
                    <th>Type</th>
                    <th>File</th>
                    <th>Date Time</th>
                </tr>
              <?php
                $query="select * from tblgallery";
                $result=mysqli_query($con,$query);
                $s=1;
                while($row=mysqli_fetch_assoc($result)){ ?>
                    <tr>
                        <td><a href="addgallery.php?idgallery=<?php echo $row['idgallery']; ?>&operation=update" class="btn btn-success">Update</a></td>
                        <td><a href="addgallery.php?idgallery=<?php echo $row['idgallery']; ?>&operation=delete" class="btn btn-danger">Delete</a></td>
                        <td><?php echo $s++; ?></td>
                        <td><?php echo $row['gallerytype']; ?></td>
                        <td><img src="gallery/<?php echo $row['galleryfile']; ?>" height=50 width=100></td>
                        <td><?php echo $row['insertdatetime']; ?></td>
                     </tr>
               <?php } ?>
             </table>
      </div>
    </main>
<?php include_once('adminfooter.php'); ?>
