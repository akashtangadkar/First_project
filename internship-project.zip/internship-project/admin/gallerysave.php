<?php 
    include_once('conn.php'); 
    if(isset($_POST['insert'])) {
        $gallerytype=trim($_POST['gallerytype']);
        $currentdatetime=date('Y-m-d h:i:s');
        if(!file_exists("gallery")){ mkdir("gallery", 0777, true); }
        $target_dir = "gallery/";
        $post_tmp_img = $_FILES["galleryfile"]["tmp_name"];
        $post_imag = $_FILES["galleryfile"]["name"];
         move_uploaded_file($post_tmp_img,"$target_dir"."$post_imag");
        $sql_query="insert into tblgallery(gallerytype,galleryfile,insertdatetime) values('$gallerytype','$post_imag','$currentdatetime')";
        mysqli_query($con,$sql_query);
        echo "<script> alert('Gallery Data Save Successfully...!'); </script>";
        echo "<script> window.location='addgallery.php' </script>";
    }
    if(isset($_POST['update'])) {
        $idgallery=trim($_POST['idgallery']);
        $gallerytype=trim($_POST['gallerytype']);
        $galleryfileold=trim($_POST['galleryfileold']);
        $currentdatetime=date('Y-m-d h:i:s');
        if(!file_exists("gallery")){ mkdir("gallery", 0777, true); }
        $target_dir = "gallery/";
        $post_tmp_img = $_FILES["galleryfile"]["tmp_name"];
        $post_imag = $_FILES["galleryfile"]["name"];
        if($post_imag==''){
            $post_imag=$galleryfileold;
        }else{
            move_uploaded_file($post_tmp_img,"$target_dir"."$post_imag");
            unlink("$target_dir".$galleryfileold);
        }
        $sql_query="update tblgallery set gallerytype='$gallerytype',galleryfile='$post_imag',insertdatetime='$currentdatetime' where idgallery='$idgallery'";
        mysqli_query($con,$sql_query);
         echo "<script> alert('Gallery Data Update Successfully...!'); </script>";
        echo "<script> window.location='addgallery.php' </script>";
    }
    if(isset($_POST['delete'])) {
        $idgallery=trim($_POST['idgallery']);
        $galleryfileold=trim($_POST['galleryfileold']);
        $currentdatetime=date('Y-m-d h:i:s');
        if(!file_exists("gallery")){ mkdir("gallery", 0777, true); }
        $target_dir = "gallery/";
        $sql_query="delete from tblgallery where idgallery='$idgallery'";
        mysqli_query($con,$sql_query);
        unlink("$target_dir".$galleryfileold);
        echo "<script> alert('Gallery Data Delete Successfully...!'); </script>";
        echo "<script> window.location='addgallery.php' </script>";
    }
    ?>