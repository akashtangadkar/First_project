<?php 
    include_once('sidebar.php');  
    include_once('conn.php'); 
    if(isset($_POST['insert'])) {
        $sliderdata=trim($_POST['sliderdata']);
        $currentdatetime=date('Y-m-d h:i:s');
        if(!file_exists("logo")){ mkdir("logo", 0777, true); }
        $target_dir = "logo/";
        $post_tmp_img = $_FILES["logo"]["tmp_name"];
        $post_imag = $_FILES["logo"]["name"];
         move_uploaded_file($post_tmp_img,"$target_dir"."$post_imag");
        $sql_query="insert into tblslider(sliderdata,logo,insertdatetime) values('$sliderdata','$post_imag','$currentdatetime')";
        mysqli_query($con,$sql_query);
        echo "<script> alert('Slider Data Save Successfully...!'); </script>";
        echo "<script> window.location='addslider.php' </script>";
    }
    if(isset($_POST['update'])) {
        $idslider=trim($_POST['idslider']);
        $sliderdata=trim($_POST['sliderdata']);
        $logoold=trim($_POST['logoold']);
        $currentdatetime=date('Y-m-d h:i:s');
        if(!file_exists("logo")){ mkdir("logo", 0777, true); }
        $target_dir = "logo/";
        $post_tmp_img = $_FILES["logo"]["tmp_name"];
        $post_imag = $_FILES["logo"]["name"];
        if($post_imag==''){
            $post_imag=$logoold;
        }else{
            move_uploaded_file($post_tmp_img,"$target_dir"."$post_imag");
            unlink("$target_dir"."$logoold");
        }
        $sql_query="update tblslider set sliderdata='$sliderdata',logo='$post_imag',insertdatetime='$currentdatetime' where idslider='$idslider'";
        mysqli_query($con,$sql_query);
        echo "<script> alert('Slider Data Update Successfully...!'); </script>";
        echo "<script> window.location='addslider.php' </script>";
    }
    if(isset($_POST['delete'])) {
        $idslider=trim($_POST['idslider']);
        $sliderdata=trim($_POST['sliderdata']);
        $logoold=trim($_POST['logoold']);
        $currentdatetime=date('Y-m-d h:i:s');
        if(!file_exists("logo")){ mkdir("logo", 0777, true); }
        $target_dir = "logo/";
        $sql_query="delete from tblslider where idslider='$idslider'";
        mysqli_query($con,$sql_query);
        unlink("$target_dir"."$logoold");
        echo "<script> alert('Slider Data Delete Successfully...!'); </script>";
        echo "<script> window.location='addslider.php' </script>";
    }
    if($_GET['idslider']!=''){
        $query="select * from tblslider where idslider='".$_GET['idslider']."'";
        $result=mysqli_query($con,$query);
        $rowedit=mysqli_fetch_assoc($result);
    }
?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="col-12 mt-2">
        <h1 class="text-center h2">Add Slider</h1>
       </div>
       <form method="post" action="" role="form" enctype="multipart/form-data">
        <div class="messages"></div>
        <div class="controls">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group mb-2">
                        <label for="form_name">Slider Data <span class="text-danger">*</span></label>
                        <input id="sliderdata" type="text" name="sliderdata" class="form-control" placeholder="Slider Data" value="<?php echo $rowedit['sliderdata']; ?>" required>
                    </div>
                </div>
             </div>
             <div class="row">
                <div class="col-md-12">
                    <div class="form-group mb-2">
                        <label for="form_message">Slider Images <span class="text-danger">*</span></label>
                        <input type="file" id="logo" name="logo" class="form-control">
                        <input type="hidden" id="logoold" name="logoold" class="form-control" value="<?php echo $rowedit['logo']; ?>">
                        <br>
                        <?php if($_GET['idslider']!=''){ ?>
                        <img src="logo/<?php echo $rowedit['logo']; ?>" height=50 width=50> 
                        <?php } ?>
                    </div>
                </div>
                <div class="col-md-12 mt-2">
                    <?php if($_GET['operation']==""){  ?>
                    <input type="submit" name="insert" class="btn btn-success btn-send" value="Insert">
                <?php  } else if($_GET['operation']=="update"){  ?>
                    <input type="submit" name="update" class="btn btn-warning btn-send" value="Update">
                <?php  }else if($_GET['operation']=="delete"){ ?>
                    <input type="submit" name="delete" class="btn btn-danger btn-send" value="Delete"> 
                    <?php   } ?>
                    <input type="hidden" name="idslider" id="idslider" value="<?php echo $_GET['idslider']; ?>">
                    <a href="addslider.php" class="btn btn-info">Refresh</a>
                </div>
            </div>
        </div>
    </form>
    <hr>
       <h3 class="text-center">Slider List</h3>                    
       <div class="table-responsive">
            <table class="table table-bordered">
                <tr class="bg-dark text-white">
                    <th>Update</th>
                    <th>Delete</th>
                    <th>Sr.No.</th>
                    <th>Slider Data</th>
                    <th>Image</th>
                    <th>Date Time</th>
                </tr>
              <?php
                $query="select * from tblslider";
                $result=mysqli_query($con,$query);
                $s=1;
                while($row=mysqli_fetch_assoc($result)){ ?>
                    <tr>
                        <td><a href="addslider.php?idslider=<?php echo $row['idslider']; ?>&operation=update" class="btn btn-success">Update</a></td>
                        <td><a href="addslider.php?idslider=<?php echo $row['idslider']; ?>&operation=delete" class="btn btn-danger">Delete</a></td>
                        <td><?php echo $s++; ?></td>
                        <td><?php echo $row['sliderdata']; ?></td>
                        <td><img src="logo/<?php echo $row['logo']; ?>" height=50 width=100></td>
                        <td><?php echo $row['insertdatetime']; ?></td>
                     </tr>
               <?php } ?>
             </table>
      </div>
    </main>
<?php include_once('adminfooter.php'); ?>
