<?php 
    include_once('sidebar.php');  
    include_once('conn.php'); 
?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Show Contact Us List</h1>
       </div>
       <form method="post" action="" enctype="multipart/form-data">
       <?php  if($_GET['operation']=="delete"){ ?>
          <input type="submit" name="delete" class="btn btn-danger btn-send" value="Delete">
          <input type="hidden" name="idcontact" id="idcontact" value="<?php echo $_GET['idcontact']; ?>">
          <a href="showcontactlist.php" class="btn btn-info">Refresh</a> 
          <?php  } ?>
       </form>
          <?php if(isset($_POST['delete'])) {
                $idcontact=trim($_POST['idcontact']);
                $sql_query="delete from tblcontactus where idcontact='$idcontact'";
                mysqli_query($con,$sql_query);
                echo "<script> alert('Contact Us Data Delete Successfully...!'); </script>";
                echo "<script> window.location='showcontactlist.php' </script>";
            }
            ?>
       <div class="table-responsive">
            <table class="table table-bordered">
                <tr>
                     <th>Delete</th>
                    <th>SrNo</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email Id</th>
                    <th>Mobile No</th>
                    <th>Message</th>
                    <th>Date Time</th>
                </tr>
              <?php
                $query="select * from tblcontactus";
                $result=mysqli_query($con,$query);
                while($row=mysqli_fetch_assoc($result)){ ?>
                    <tr>
                       <td><a href="showcontactlist.php?idcontact=<?php echo $row['idcontact']; ?>&operation=delete" class="btn btn-danger">Delete</a></td>
                        <td><?php echo $row['idcontact']; ?></td>
                        <td><?php echo $row['fname']; ?></td>
                        <td><?php echo $row['lname']; ?></td>
                        <td><?php echo $row['emailid']; ?></td>
                        <td><?php echo $row['mobile']; ?></td>
                        <td><?php echo $row['message']; ?></td>
                        <td><?php echo $row['insertdatetime']; ?></td>
                     </tr>
               <?php } ?>
             </table>
      </div>
    </main>
<?php include_once('adminfooter.php'); ?>
