<?php 
include_once('conn.php');
if(isset($_POST['insert'])){
    $companyname=$_POST['companyname'];
    $companydesc=$_POST['companydesc'];
    $currentdatetime=date('Y-m-d h:i:s');
    if(!file_exists("about")){ mkdir("about", 0777, true); }
    $target_dir="about/";
    $post_tmp_img = $_FILES["companylogo"]["tmp_name"]; //file upload
    $post_imag = $_FILES["companylogo"]["name"]; //file database upload
    move_uploaded_file($post_tmp_img,"$target_dir"."$post_imag");
    $sql="insert into tblaboutus (companyname,companydesc,companylogo,insertdatetime) values('$companyname','$companydesc','$post_imag','$currentdatetime')";
    mysqli_query($con,$sql);
    echo "<script> alert('about Data Save Successfully...!'); </script>";
    echo "<script> window.location='addboutus.php' </script>";
}
if(isset($_POST['update'])){
    $companylogo_old=$_POST['companylogo_old'];
    $companyname=$_POST['companyname'];
    $companydesc=$_POST['companydesc'];
    $idaboutus=$_POST['idaboutus'];
    $currentdatetime=date('Y-m-d h:i:s');
    if(!file_exists("about")){ mkdir("about", 0777, true); }
    $target_dir="about/";
    $post_tmp_img = $_FILES["companylogo"]["tmp_name"]; //file upload
    $post_imag = $_FILES["companylogo"]["name"]; //file database upload
    if($post_imag==''){
        $post_imag=$companylogo_old;
    }else{
        move_uploaded_file($post_tmp_img,"$target_dir"."$post_imag");
        unlink("$target_dir".$companylogo_old);
    }
    $upd="update tblaboutus set companyname='$companyname',companydesc='$companydesc',companylogo='$post_imag',insertdatetime='$currentdatetime' where idaboutus='$idaboutus'";
    mysqli_query($con,$upd);
    echo "<script> alert('About Data Update Successfully...!'); </script>";
    echo "<script> window.location='addboutus.php' </script>";
}
if(isset($_POST['delete'])){
    $companylogo_old=$_POST['companylogo_old'];
    $idaboutus=$_POST['idaboutus'];
    $target_dir="about/";
    $upd="delete from tblaboutus where idaboutus='$idaboutus'";
    mysqli_query($con,$upd);
    unlink("$target_dir".$companylogo_old);
    echo "<script> alert('About Data Delete Successfully...!'); </script>";
    echo "<script> window.location='addboutus.php' </script>";
}
?>