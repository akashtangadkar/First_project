<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../jquery.min.js"></script>
</head>
<body class="bg-success">
    <?php 
    include_once('conn.php');
    session_start();
    session_destroy();
    session_start();
    if(isset($_POST['login'])){
        $username=trim($_POST['username']);
        $password=trim($_POST['password']);
        $sel="select * from tbluser where username='$username' and password='$password'";
        $result=mysqli_query($con,$sel);
        $resultcount=mysqli_num_rows($result);
        if($resultcount>0){
            $rows=mysqli_fetch_assoc($result);
            $_SESSION['iduser']=$rows['iduser'];
            $_SESSION['username']=$rows['username'];
            echo "<script> alert('login Successfully..!'); </script>";
            echo "<script> window.location='dashboard.php'; </script>";
        }else{
            echo "<script> alert('Invalid Login details please try again..!'); </script>";
            echo "<script> window.location='index.php'; </script>";
        }
    }
    ?>
    <div class="container mt-5 p-5 bg-white" style="max-width:700px;  border-radius: 10px;
    box-shadow: 10px 10px 5px black;" >
    <div class="row">
        <div class="col-6">
            <img src="gallery/login.png" alt="login" class="img-thumbnail">
        </div>
        <div class="col-6">
            <form action="" method="post">
                <div class="row mb-3">
                    <div class="col">
                        <label for="">User Name</label>
                    </div>
                    <div class="col">
                        <input type="text"  class="form-control" name="username" id="username">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col">
                        <label for="">Password</label>
                    </div>
                    <div class="col">
                        <input type="password"  class="form-control" name="password" id="password">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col text-center">
                    <input type="submit"  class="btn btn-primary" name="login" id="login" value="Login">
                        <input type="reset"  class="btn btn-danger" name="Reset" id="Reset" value="Reset">
                    </div>
                </div>
            </form>
        </div>
    </div>
    </div>
</body>
</html>