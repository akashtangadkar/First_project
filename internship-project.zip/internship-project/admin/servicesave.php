<?php 
include_once('conn.php');
if(isset($_POST['insert'])){
    $servicename=$_POST['servicename'];
    $servicedesc=$_POST['servicedesc'];
    $currentdatetime=date('Y-m-d h:i:s');
    if(!file_exists("services")){ mkdir("services", 0777, true); }
    $target_dir="services/";
    $post_tmp_img = $_FILES["serviceimage"]["tmp_name"]; //file upload
    $post_imag = $_FILES["serviceimage"]["name"]; //file database upload
    move_uploaded_file($post_tmp_img,"$target_dir"."$post_imag");
    $sql="insert into tblservices (servicename,servicedesc,serviceimage,insertdatetime) values('$servicename','$servicedesc','$post_imag','$currentdatetime')";
    mysqli_query($con,$sql);
    echo "<script> alert('Services Data Save Successfully...!'); </script>";
    echo "<script> window.location='addservices.php' </script>";
}
if(isset($_POST['update'])){
    $serviceimage_old=$_POST['serviceimage_old'];
    $servicename=$_POST['servicename'];
    $servicedesc=$_POST['servicedesc'];
    $idservice=$_POST['idservice'];
    $currentdatetime=date('Y-m-d h:i:s');
    if(!file_exists("services")){ mkdir("services", 0777, true); }
    $target_dir="services/";
    $post_tmp_img = $_FILES["serviceimage"]["tmp_name"]; //file upload
    $post_imag = $_FILES["serviceimage"]["name"]; //file database upload
    move_uploaded_file($post_tmp_img,"$target_dir"."$post_imag");
    if($post_imag==''){
        $post_imag=$serviceimage_old;
    }else{
        move_uploaded_file($post_tmp_img,"$target_dir"."$post_imag");
        unlink("$target_dir".$serviceimage_old);
    }
    $upd="update tblservices set servicename='$servicename',servicedesc='$servicedesc',serviceimage='$post_imag',insertdatetime='$currentdatetime' where idservice='$idservice'";
    mysqli_query($con,$upd);
    echo "<script> alert('Services Data Update Successfully...!'); </script>";
    echo "<script> window.location='addservices.php' </script>";
}
if(isset($_POST['delete'])){
    $serviceimage_old=$_POST['serviceimage_old'];
    $idservice=$_POST['idservice'];
    $target_dir="services/";
    $upd="delete from tblservices where idservice='$idservice'";
    mysqli_query($con,$upd);
    unlink("$target_dir".$serviceimage_old);
    echo "<script> alert('Services Data Delete Successfully...!'); </script>";
    echo "<script> window.location='addservices.php' </script>";
}
?>