<?php
	require_once("connection.php");
?>
<!DOCTYPE html>
<html>

<head>
    <title>Example</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/datatables.min.css" rel="stylesheet">
    <link href="assets/fontawesome/css/all.css" rel="stylesheet">
</head>
