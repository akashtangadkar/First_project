<!DOCTYPE HTML>
<html>  
<body>
<form action="welcome.php" method="post">
Name: <input type="text" name="name"><br><br>
E-mail: <input type="text" name="email"><br><br>
<input type="submit">
</form>
</body>
</html>
